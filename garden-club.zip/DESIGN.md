# Garden Club Dominator — Design Document

**Status:** Living document reflecting the current playable prototype  
**Last updated:** 2026-11-10

## Theme & Fantasy
- Gardening incremental / “numbers go up” game.
- City-wide garden club competing for the title **Gardener of the Month**.
- Humorous tone about dominating the vegetable gardening scene.
- Player grows increasingly desirable vegetables and supplies larger markets.

## Core Loop (per veggie plot)
- Each veggie has its own plot with local storage that holds **1 ready harvest**.
- First click: button says **“Plant”** → growth cycle starts.
- Progress bar fills (time shown as `m:ss.xx`).
- When ready, the same button becomes **“Harvest”** and is clickable.
- Click Harvest → receive current yield, inventory increases, next cycle starts automatically.
- While growing, the Harvest button is **disabled** (label stays “Harvest”).
- After the initial Plant, only Harvest requires a click until automated.
- Prestige can later grant **Auto-Plant**.

## Plants & Yield
- Buying a plant increases harvest amount by **+1** (additive).
- Every **25 plants** grants a speed bonus (cycle time ×0.90).
- Plant cost starts at the veggie’s first-plant cost, then multiplies by **×1.15** each purchase.
- Buy multiplier (x1 / x10 / x100 / Max) shows total cost.

## Veggie Progression
- Start with **Kale** unlocked. Every subsequent veggie unlocks at **10 plants** of the previous one.
- All 9 veggies are intended to be unlockable within roughly an hour with upgrades and automation.

| # | Veggie              | Unlock condition     | First plant cost | Base cycle   | Sell price |
|---|---------------------|----------------------|------------------|--------------|------------|
| 1 | Kale                | Starting             | 5                | 5 seconds    | 1          |
| 2 | Spinach             | 10 Kale plants       | 25               | 20 seconds   | 4          |
| 3 | Beets               | 10 Spinach plants    | 200              | 1.5 minutes  | 20         |
| 4 | Swiss Chard         | 10 Beets plants      | 1,500            | 6 minutes    | 100        |
| 5 | Radishes            | 10 Swiss Chard plants| 10,000           | 20 minutes   | 500        |
| 6 | Carrots             | 10 Radishes plants   | 75,000           | 1 hour       | 2,500      |
| 7 | Broccoli            | 10 Carrots plants    | 500,000          | 3 hours      | 15,000     |
| 8 | Bell Peppers        | 10 Broccoli plants   | 3,500,000        | 6 hours      | 80,000     |
| 9 | Heirloom Tomatoes   | 10 Bell Pepper plants| 25,000,000       | **12 hours** | 500,000    |

- Plots display in a fixed 3×3 grid.
- Next locked veggie is always visible with its unlock requirement and cost.

## Selling
- Each veggie has its own Sell button.
- Once auto-sell is purchased, the button becomes disabled and reads **“Auto”**.
- Prices are shown with a space before “c” (e.g. `12 c`).

## Neighbors (three categories)

### Helpful Neighbors (Managers / Automations)
Purchased with coins. Named per veggie:

| Veggie              | Auto-Harvest (10× first plant) | Auto-Sell (50× first plant) |
|---------------------|--------------------------------|-----------------------------|
| Kale                | Eager Neighbor Kid (100 c)     | Kid with a Wagon (500 c)    |
| Spinach             | Garden Club Volunteer (500 c)  | Stand Helper (2.5k c)       |
| Beets               | Backyard Botanist (5.0k c)     | Market Runner (25.0k c)     |
| Swiss Chard         | Retired Horticulturist (50.0k c)| Chard Courier (250.0k c)   |
| Radishes            | Weekend Weeder (500.0k c)      | Radish Runner (2.5M c)      |
| Carrots             | Carrot Enthusiast (5.0M c)     | Produce Porter (25.0M c)    |
| Broccoli            | Club Secretary (50.0M c)       | Broccoli Broker (250.0M c)  |
| Bell Peppers        | Pepper Pro (500.0M c)          | Pepper Packer (2.5B c)      |
| Heirloom Tomatoes   | Master Gardener (5.0B c)       | Tomato Tycoon (25.0B c)     |

- Auto-harvest unlocks when the veggie is unlocked.
- Auto-sell unlocks at 10 plants of that veggie.
- Once purchased, the Sell button becomes permanently disabled and reads **“Auto”**.
- A per-plot **AutoBuy** toggle appears next to the Buy button (enabled after the global Autobuy upgrade).

### Purchase Cost Reference
| Item                        | Cost formula / value          |
|-----------------------------|-------------------------------|
| First plant of a veggie     | See veggie table              |
| Subsequent plants           | ×1.15 previous plant          |
| Auto-Harvest                | 10× first plant (Kale = 100 c)|
| Auto-Sell                   | 50× first plant (Kale = 500 c)|
| Per-crop +10% speed         | 100× first plant, +10% each level |
| Global +25% speed           | 1000 c                        |
| Autobuy upgrade             | 1.0T c (after all 9 unlocked) |

### Generous Neighbors (Speed Upgrades)
- Per-crop +10% speed upgrades unlock every 10 plants of that veggie.
- Each successive level costs 10% more than the previous.
- Level is displayed on the button.
- Global +25% speed (“Neighborhood Compost Tea”) appears on every 3rd veggie unlock (and later every 25 plants).
- Speed upgrades only affect veggies that are already unlocked at the time of purchase.

### Supportive Neighbors (Prestige resource)
- Accrue from sales, but the first meaningful Supportive Neighbor does not appear until **10 Heirloom Tomato plants** are owned.
- Converted into **Gardener of the Month Trophies** on prestige.
- Counter resets on prestige.

## Prestige Upgrades (Locked)

Prestige converts Supportive Neighbors into trophies. Upgrades must be purchased in the Supportive Neighbors tab before they take effect. All effects are permanent.

| # | Upgrade | Cost (Trophies) | Effect |
|---|---------|-----------------|--------|
| 1 | **Better Soil** | 1 | ×2 base harvest amount |
| 2 | **Enriched Compost** | 1 | ×1.5 base cycle speed |
| 3 | **Ongoing Support** | 2 | Keeps Auto-Harvest and Auto-Sell through prestige |
| 4 | **Perpetual Winner** | 3 | Unlocks continuous trophy accumulation (more than 1 trophy per prestige) |

### Prestige rules
- Prestige unlocks after **Broccoli is unlocked** (and the celebration has played).
- Unlocking Broccoli automatically grants **1 Supportive Neighbor**.
- Prestige requires at least 1 Supportive Neighbor.
- After Perpetual Winner is unlocked, trophies require progressively more Supportive Neighbors to accrue (soft scaling).
- Full reset of plants, coins, inventory, and named neighbors. Keep trophies and purchased prestige upgrades.
- After prestige, upgrades appear in the Supportive Neighbors tab and must be bought before they take effect.

## Market Upgrades
- Market upgrades appear on the Market card (not in the Upgrades tab).
- First upgrade: **Farmers Market Stand** (unlocks at 10 Beets) — +50% sell price to veggies unlocked at time of purchase.
- Additional tiers can be added later.

## UI
- Top bar, tabs, and market match the width of the 3-plot grid.
- Progress bars show remaining time with two decimal places.
- Red-dot notifications on the Upgrades tab and sub-tabs when something is affordable.
- Upgrade cards are compact.
- Buy multiplier button sits next to the Buy button.

## To-Do / Recent Decisions
- Sell button unavailable and grey until inventory exists. **(Implemented)**
- Neighborhood Compost Tea starts at **1.0k c**; each additional level costs previous +10%. **(Implemented)**
- Global speed upgrades only affect veggies that were already unlocked at the moment the upgrade was purchased. **(Implemented)**
- Testing-only time scale control: 1× / 2× / 5×. **(Implemented)**
- First-plant costs lowered to accelerate early/mid progress.
- Per-plant ×1.02 speed **and** ×1.02 harvest multipliers. **(Implemented)**
- Recurring upgrade costs scale by +25% per level. **(Implemented)**
- Prestige unlocks after Broccoli is unlocked; first Supportive Neighbor appears then. **(Implemented)**
- Kale Growth Serum Lvl 1 = 1.0k c. **(Implemented)**
- Display purchase tables in UI (optional reference panel).
- Further prestige upgrades and balancing.

## Planned Mechanics (not yet implemented)
- **Per-plant speed**: Each plant of a veggie multiplies that veggie’s cycle speed by ×1.01 (stacks with the every-25-plants ×0.90 bonus and upgrade multipliers).
- **Multiplier button sizing**: Match height of Buy/Harvest; width locked to fit “Max”.
- **Sell button state**: Disabled + grey until inventory > 0; becomes permanently “Auto” once auto-sell is purchased.
