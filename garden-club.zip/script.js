// Garden Club Dominator — multi-veggie prototype matching DESIGN.md

const VEGGIES = [
  { id: "kale", name: "Kale", unlockPlants: 0, firstCost: 5, baseCycle: 5, sellPrice: 1, unlocked: true },
  { id: "spinach", name: "Spinach", unlockPlants: 10, firstCost: 25, baseCycle: 20, sellPrice: 4, unlocked: false },
  { id: "beets", name: "Beets", unlockPlants: 10, firstCost: 200, baseCycle: 90, sellPrice: 20, unlocked: false },
  { id: "chard", name: "Swiss Chard", unlockPlants: 10, firstCost: 1500, baseCycle: 360, sellPrice: 100, unlocked: false },
  { id: "radishes", name: "Radishes", unlockPlants: 10, firstCost: 10000, baseCycle: 1200, sellPrice: 500, unlocked: false },
  { id: "carrots", name: "Carrots", unlockPlants: 10, firstCost: 75000, baseCycle: 3600, sellPrice: 2500, unlocked: false },
  { id: "broccoli", name: "Broccoli", unlockPlants: 10, firstCost: 500000, baseCycle: 10800, sellPrice: 15000, unlocked: false },
  { id: "peppers", name: "Bell Peppers", unlockPlants: 10, firstCost: 3500000, baseCycle: 21600, sellPrice: 80000, unlocked: false },
  { id: "tomatoes", name: "Heirloom Tomatoes", unlockPlants: 10, firstCost: 25000000, baseCycle: 43200, sellPrice: 500000, unlocked: false },
];

const NEIGHBORS = {
  kale:      { harvest: "Eager Neighbor Kid",      sell: "Kid with a Wagon",     speed: "Kale Growth Serum" },
  spinach:   { harvest: "Garden Club Volunteer",   sell: "Stand Helper",         speed: "Spinach Turbo Soil" },
  beets:     { harvest: "Backyard Botanist",       sell: "Market Runner",        speed: "Beet Booster Blend" },
  chard:     { harvest: "Retired Horticulturist",  sell: "Chard Courier",        speed: "Chard Catalyst" },
  radishes:  { harvest: "Weekend Weeder",          sell: "Radish Runner",        speed: "Radish Rocket Fuel" },
  carrots:   { harvest: "Carrot Enthusiast",       sell: "Produce Porter",       speed: "Carrot Growth Cocktail" },
  broccoli:  { harvest: "Club Secretary",          sell: "Broccoli Broker",      speed: "Broccoli Boost" },
  peppers:   { harvest: "Pepper Pro",              sell: "Pepper Packer",        speed: "Pepper Power Serum" },
  tomatoes:  { harvest: "Master Gardener",         sell: "Tomato Tycoon",        speed: "Heirloom Hyper-Growth Formula" },
};

const state = {
  coins: 0,
  supportive: 0,
  trophies: 0,
  prestigeUpgrades: {
    betterSoil: false,
    enrichedCompost: false,
    ongoingSupport: false,
    perpetualWinner: false,
  },
  marketUpgrades: {
    farmersMarket: false,
  },
  betterSoil: 1,
  buyMode: 1, // legacy, now per-plot
  globalSpeed: 1,
  globalSpeedLevels: 0,
  globalSpeedAffected: [],
  timeScale: 1,
  plots: {},
  upgrades: {},
  autobuy: false,
  notified: {},
};

VEGGIES.forEach(v => {
  state.plots[v.id] = {
    plants: v.unlocked ? 1 : 0,
    plantCost: v.firstCost,
    inventory: 0,
    progress: 0,
    growing: false,
    ready: false,
    hasStarted: false,
    autoHarvest: false,
    autoSell: false,
    speedLevels: 0,
    buyMode: 1,
    autoBuy: false,
  };
  state.upgrades[v.id] = { harvest: false, sell: false, speedBought: 0 };
});

const coinsEl = document.getElementById("coins");
const supportiveEl = document.getElementById("supportive");
const trophiesEl = document.getElementById("trophies");
const plotsEl = document.getElementById("plots");
const helpfulList = document.getElementById("helpful-list");
const generousList = document.getElementById("generous-list");
const prestigeBtn = document.getElementById("prestige-btn");
const prestigeInfo = document.getElementById("prestige-info");

function format(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "k";
  return Math.floor(n).toString();
}

function formatTime(seconds) {
  if (seconds <= 0) return "0:00.00";
  const m = Math.floor(seconds / 60);
  const s = (seconds % 60).toFixed(2);
  return `${m}:${s.padStart(5, "0")}`;
}

function getYield(plot) {
  const plantMult = Math.pow(1.02, plot.plants);
  return plot.plants * state.betterSoil * plantMult;
}

function getCycleTime(veggie, plot) {
  const batches = Math.floor(plot.plants / 25);
  const plantSpeed = Math.pow(1.02, plot.plants);
  let globalMult = 1;
  if (state.globalSpeedAffected.includes(veggie.id)) {
    globalMult = state.globalSpeed;
  }
  const speedMult = (1 + plot.speedLevels * 0.10) * globalMult * plantSpeed;
  return veggie.baseCycle * Math.pow(0.90, batches) / speedMult;
}

let lastUnlockState = "";

let lastUpgradeState = "";

function updateUI() {
  coinsEl.textContent = format(state.coins);
  if (supportiveEl) supportiveEl.textContent = state.supportive.toFixed(2);
  if (trophiesEl) trophiesEl.textContent = state.trophies;

  // Red dots — only when something is actually affordable and unlocked
  const upgradesDot = document.getElementById("upgrades-dot");
  const helpfulDot = document.getElementById("helpful-dot");
  const generousDot = document.getElementById("generous-dot");

  let helpfulNew = false;
  let generousNew = false;
  VEGGIES.forEach(v => {
    if (!v.unlocked) return;
    const plot = state.plots[v.id];
    const up = state.upgrades[v.id];
    const harvestCost = v.id === "kale" ? 100 : Math.floor(v.firstCost * 10);
    const sellCost = v.id === "kale" ? 500 : Math.floor(v.firstCost * 50);
    if (!up.harvest && state.coins >= harvestCost) helpfulNew = true;
    if (plot.plants >= 10 && !up.sell && state.coins >= sellCost) helpfulNew = true;
    const availableSpeed = Math.floor(plot.plants / 10);
    if (availableSpeed > up.speedBought) {
      const cost = Math.floor(v.firstCost * 100 * Math.pow(1.25, up.speedBought));
      if (state.coins >= cost) generousNew = true;
    }
  });
  if (VEGGIES.every(v => v.unlocked) && !state.autobuy && state.coins >= 1e12) helpfulNew = true;

  if (upgradesDot) {
    const any = helpfulNew || generousNew;
    upgradesDot.style.display = any ? "inline-block" : "none";
    const tabBtn = document.getElementById("upgrades-tab-btn");
    if (tabBtn) tabBtn.classList.toggle("has-upgrade", any);
  }
  if (helpfulDot) helpfulDot.style.display = helpfulNew ? "inline-block" : "none";
  if (generousDot) generousDot.style.display = generousNew ? "inline-block" : "none";

  const unlockState = VEGGIES.map(v => v.unlocked + ":" + (state.plots[v.id]?.plants || 0)).join(",");
  const needsRebuild = plotsEl.children.length === 0 || unlockState !== lastUnlockState;
  lastUnlockState = unlockState;

  // ... (plot rebuild logic stays the same)

  if (needsRebuild) {
    plotsEl.innerHTML = "";
    VEGGIES.forEach((v, idx) => {
      if (!v.unlocked) return; // only show unlocked veggies

      const plot = state.plots[v.id];
      const div = document.createElement("div");
      div.className = "plot";
      div.dataset.veggie = v.id;

      div.innerHTML = `
        <h3>${v.name} <span class="plant-count small"></span></h3>
        <div class="progress-container">
          <div class="progress-bar"></div>
          <div class="progress-text"></div>
        </div>
        <div class="button-row">
          <button class="action" data-action="${v.id}"></button>
          <button class="buy" data-buy="${v.id}"></button>
          <button class="buy-mode" data-mode="${v.id}">x1</button>
        </div>
        <button class="sell" data-sell="${v.id}"></button>
        <p class="small stats-info"></p>
        <div class="tooltip"></div>
      `;
      plotsEl.appendChild(div);
    });

    // Always show next locked veggie once previous is unlocked
    const nextLocked = VEGGIES.find(v => !v.unlocked);
    if (nextLocked) {
      const prev = VEGGIES[VEGGIES.indexOf(nextLocked) - 1];
      if (prev && state.plots[prev.id] && (prev.unlocked || state.plots[prev.id].plants > 0)) {
        const prevPlot = state.plots[prev.id];
        const canUnlock = prevPlot.plants >= nextLocked.unlockPlants && state.coins >= nextLocked.firstCost;
        const div = document.createElement("div");
        div.className = "plot";
        div.innerHTML = `
          <h3>${nextLocked.name} (Locked)</h3>
          <p class="small">Unlocks at ${nextLocked.unlockPlants} ${prev.name} plants · First plant: ${format(nextLocked.firstCost)}c</p>
          <button class="buy" data-unlock="${nextLocked.id}" ${canUnlock ? "" : "disabled"}>
            Unlock & Plant (${format(nextLocked.firstCost)}c)
          </button>
        `;
        plotsEl.appendChild(div);
      }
    }
  }

  // Update existing plot elements (only unlocked ones are in the DOM)
  VEGGIES.forEach(v => {
    if (!v.unlocked) return;
    const div = plotsEl.querySelector(`[data-veggie="${v.id}"]`);
    if (!div) return;
    const plot = state.plots[v.id];

    const cycle = getCycleTime(v, plot);
    const remaining = plot.growing ? Math.max(0, (1 - plot.progress) * cycle) : 0;
    const yieldAmt = getYield(plot);

    const bar = div.querySelector(".progress-bar");
    const text = div.querySelector(".progress-text");
    const actionBtn = div.querySelector(".action");
    const buyBtn = div.querySelector(".buy");
    const sellBtn = div.querySelector(".sell");
    const yieldInfo = div.querySelector(".stats-info");
    const modeBtn = div.querySelector(".buy-mode");
    const plantCount = div.querySelector(".plant-count");

    if (bar) bar.style.width = Math.min(100, plot.progress * 100) + "%";
    if (text) {
      text.textContent = plot.ready ? "Ready!" : plot.hasStarted ? formatTime(remaining) : "Ready to plant";
    }
    if (actionBtn) {
      actionBtn.textContent = !plot.hasStarted ? "Plant" : "Harvest";
      actionBtn.disabled = plot.growing && !plot.ready;
    }
    if (buyBtn) {
      const mode = plot.buyMode || 1;
      const modeLabel = mode === "max" ? "Max" : `x${mode}`;
      let totalCost = 0;
      let tempCost = plot.plantCost;
      const count = mode === "max" ? 50 : Number(mode) || 1;
      for (let i = 0; i < count; i++) {
        totalCost += tempCost;
        tempCost = Math.max(tempCost + 1, Math.ceil(tempCost * 1.15));
      }
      if (mode === "max") {
        totalCost = 0;
        tempCost = plot.plantCost;
        while (totalCost + tempCost <= state.coins && totalCost < 1e12) {
          totalCost += tempCost;
          tempCost = Math.max(tempCost + 1, Math.ceil(tempCost * 1.15));
        }
        if (totalCost === 0) totalCost = plot.plantCost;
      }
      buyBtn.textContent = `Buy ${modeLabel} (${format(totalCost)} c)`;
      buyBtn.disabled = state.coins < totalCost;
    }
    if (sellBtn) {
      const veggie = VEGGIES.find(vv => vv.id === v.id);
      sellBtn.textContent = plot.autoSell ? "Auto" : `Sell (${format(plot.inventory * veggie.sellPrice)} c)`;
      sellBtn.disabled = plot.autoSell || plot.inventory <= 0;
    }
    if (modeBtn) {
      const mode = plot.buyMode || 1;
      modeBtn.textContent = mode === "max" ? "Max" : "x" + mode;
    }
    if (yieldInfo) {
      const perMinute = (yieldAmt / cycle) * 60;
      const incomePerMin = perMinute * v.sellPrice;
      const usePerSec = perMinute > 1000;
      const rate = usePerSec ? (perMinute / 60).toFixed(1) + "/s" : perMinute.toFixed(1) + "/min";
      const income = usePerSec ? (incomePerMin / 60).toFixed(1) + "/s" : incomePerMin.toFixed(1) + "/min";
      const speedPct = Math.round(plot.speedLevels * 10);
      const globalPct = Math.round((state.globalSpeed - 1) * 100);
      const mults = [];
      if (speedPct > 0) mults.push(`+${speedPct}% spd`);
      if (globalPct > 0) mults.push(`+${globalPct}% global`);
      const multText = mults.length ? ` · ${mults.join(" ")}` : "";
      yieldInfo.textContent = `Plants: ${plot.plants} · Inv: ${format(plot.inventory)} · Prod: ${rate} · Income: ${income}${multText}`;
    }
    if (plantCount) plantCount.textContent = `(${plot.plants} plants)`;

    const tooltip = div.querySelector(".tooltip");
    if (tooltip) {
      const up = state.upgrades[v.id];
      const lines = [];
      if (up.harvest) lines.push("Auto-Harvest");
      if (up.sell) lines.push("Auto-Sell");
      if (up.speedBought > 0) lines.push(`Speed ×${(1 + up.speedBought * 0.1).toFixed(2)}`);
      lines.push(`Plant mult ×${Math.pow(1.02, plot.plants).toFixed(2)}`);
      if (state.prestigeUpgrades.betterSoil) lines.push("Better Soil ×2");
      if (state.prestigeUpgrades.enrichedCompost) lines.push("Enriched Compost ×1.5");
      tooltip.innerHTML = lines.map(l => `<div>${l}</div>`).join("");
    }
  });

  // Update unlock button if present
  const unlockBtn = plotsEl.querySelector("[data-unlock]");
  if (unlockBtn) {
    const nextLocked = VEGGIES.find(v => !v.unlocked);
    if (nextLocked) {
      const prev = VEGGIES[VEGGIES.indexOf(nextLocked) - 1];
      const prevPlot = state.plots[prev.id];
      const canUnlock = prevPlot.plants >= nextLocked.unlockPlants && state.coins >= nextLocked.firstCost;
      unlockBtn.disabled = !canUnlock;
    }
  }
  // Dynamic upgrade lists
  const upgradeState = VEGGIES.map(v => 
    `${v.unlocked}:${state.plots[v.id].plants}:${state.upgrades[v.id].harvest}:${state.upgrades[v.id].sell}:${state.upgrades[v.id].speedBought}`
  ).join("|") + `|${state.autobuy}|${state.globalSpeed}|${state.globalSpeedLevels}|${state.marketUpgrades.farmersMarket}`;

  if (upgradeState !== lastUpgradeState) {
    lastUpgradeState = upgradeState;

    let helpfulHTML = "";
    let generousHTML = "";

    VEGGIES.forEach(v => {
      if (!v.unlocked) return;
      const plot = state.plots[v.id];
      const up = state.upgrades[v.id];
      const names = NEIGHBORS[v.id];
      const harvestCost = v.id === "kale" ? 100 : Math.floor(v.firstCost * 10);
      const sellCost = v.id === "kale" ? 500 : Math.floor(v.firstCost * 50);
      const baseSpeedCost = Math.floor(v.firstCost * 100);

      if (plot.plants >= 1) {
        helpfulHTML += `
          <div class="upgrade-card" data-upgrade="harvest-${v.id}">
            <strong>${names.harvest}</strong> ${!up.harvest && state.coins >= harvestCost ? '<span class="red-dot"></span>' : ''}
            <p class="small">Auto-harvests ${v.name}</p>
            <button type="button" class="buy" data-upgrade="harvest-${v.id}" data-cost="${harvestCost}" data-owned="${up.harvest ? "1" : "0"}">
              ${up.harvest ? "Owned" : `Buy (${format(harvestCost)} c)`}
            </button>
          </div>`;
      }

      if (plot.plants >= 10) {
        helpfulHTML += `
          <div class="upgrade-card" data-upgrade="sell-${v.id}">
            <strong>${names.sell}</strong> ${!up.sell && state.coins >= sellCost ? '<span class="red-dot"></span>' : ''}
            <p class="small">Auto-sells ${v.name}</p>
            <button type="button" class="buy" data-upgrade="sell-${v.id}" data-cost="${sellCost}" data-owned="${up.sell ? "1" : "0"}">
              ${up.sell ? "Owned" : `Buy (${format(sellCost)} c)`}
            </button>
          </div>`;
      }

      const availableSpeed = Math.floor(plot.plants / 10);
      if (availableSpeed > up.speedBought) {
        const cost = Math.floor(baseSpeedCost * Math.pow(1.25, up.speedBought));
        generousHTML += `
          <div class="upgrade-card" data-upgrade="speed-${v.id}">
            <strong>${names.speed} ${up.speedBought + 1}</strong> ${state.coins >= cost ? '<span class="red-dot"></span>' : ''}
            <p class="small">+10% speed for ${v.name}</p>
            <button type="button" class="buy" data-upgrade="speed-${v.id}" data-cost="${cost}" data-owned="0">
              Buy Lvl ${up.speedBought + 1} (${format(cost)} c)
            </button>
          </div>`;
      }
    });

    const allUnlocked = VEGGIES.every(v => v.unlocked);
    if (allUnlocked) {
      helpfulHTML += `
        <div class="upgrade-card" data-upgrade="autobuy">
          <strong>Overeager Club Treasurer</strong> ${!state.autobuy && state.coins >= 1e12 ? '<span class="red-dot"></span>' : ''}
          <p class="small">Auto-buys plants using current multiplier</p>
          <button type="button" class="buy" data-upgrade="autobuy" data-cost="1000000000000" data-owned="${state.autobuy ? "1" : "0"}">
            ${state.autobuy ? "Owned" : "Buy (1T c)"}
          </button>
        </div>`;
    }

    const unlockedCount = VEGGIES.filter(v => v.unlocked).length;
    if (unlockedCount >= 3 && unlockedCount % 3 === 0) {
      const teaCost = Math.floor(1000 * Math.pow(1.25, state.globalSpeedLevels));
      generousHTML += `
        <div class="upgrade-card" data-upgrade="global-speed">
          <strong>Neighborhood Compost Tea ${state.globalSpeedLevels + 1}</strong> ${state.coins >= teaCost ? '<span class="red-dot"></span>' : ''}
          <p class="small">+25% speed for veggies unlocked at purchase</p>
          <button type="button" class="buy" data-upgrade="global-speed" data-cost="${teaCost}" data-owned="0">
            Buy (${format(teaCost)} c)
          </button>
        </div>`;
    }

    helpfulList.innerHTML = helpfulHTML || "<p class='small'>Unlock veggies to hire neighbors.</p>";
    generousList.innerHTML = generousHTML || "<p class='small'>Grow plants to unlock speed upgrades.</p>";
  }

  const marketKey = `${VEGGIES.find(v => v.id === "beets")?.unlocked}|${state.marketUpgrades.farmersMarket}`;
  const marketUpgradesEl = document.getElementById("market-upgrades");
  if (marketUpgradesEl && marketKey !== marketUpgradesEl.dataset.key) {
    marketUpgradesEl.dataset.key = marketKey;
    const beetsUnlocked = VEGGIES.find(v => v.id === "beets")?.unlocked;
    const cost = 1000;
    marketUpgradesEl.innerHTML = `
      <div class="upgrade-card" data-upgrade="farmers-market">
        <strong>Farmers Market Stand</strong>
        <p class="small">+50% sell price for veggies unlocked at purchase</p>
        <button type="button" class="buy" data-upgrade="farmers-market" data-cost="${cost}" data-owned="${state.marketUpgrades.farmersMarket ? "1" : "0"}" ${beetsUnlocked ? "" : "data-locked=\"1\""}>
          ${state.marketUpgrades.farmersMarket ? "Owned" : beetsUnlocked ? `Buy (${format(cost)} c)` : "Unlocks with Beets"}
        </button>
      </div>`;
  }

  document.querySelectorAll("button[data-cost]").forEach(btn => {
    const owned = btn.dataset.owned === "1";
    const locked = btn.dataset.locked === "1";
    const cost = Number(btn.dataset.cost);
    btn.classList.toggle("cant-afford", !owned && !locked && state.coins < cost);
  });

  const broccoliUnlocked = VEGGIES.find(v => v.id === "broccoli")?.unlocked;
  if (broccoliUnlocked && state.supportive < 1) state.supportive = 1;
  const canPrestige = broccoliUnlocked && state.supportive >= 1;
  prestigeBtn.disabled = !canPrestige;
  prestigeBtn.classList.toggle("ready", canPrestige);
  if (canPrestige) {
    prestigeInfo.textContent = "Prestige available! (Broccoli unlocked)";
  }
}

function startCycle(id) {
  const plot = state.plots[id];
  if (plot.growing || plot.ready) return;
  plot.growing = true;
  plot.ready = false;
  plot.progress = 0;
  plot.hasStarted = true;
}

function harvest(id) {
  const plot = state.plots[id];
  if (!plot.ready) return;
  const veggie = VEGGIES.find(v => v.id === id);
  const amount = getYield(plot);
  plot.inventory += amount;
  plot.ready = false;
  plot.growing = true;
  plot.progress = 0;
  updateUI();
}

function buyPlant(id, count = 1) {
  const plot = state.plots[id];
  const veggie = VEGGIES.find(v => v.id === id);
  for (let i = 0; i < count; i++) {
    if (state.coins < plot.plantCost) break;
    state.coins -= plot.plantCost;
    plot.plants++;
    plot.plantCost = Math.max(plot.plantCost + 1, Math.ceil(plot.plantCost * 1.15));
  }
  updateUI();
}

function onPlotClick(e) {
  const action = e.target.dataset.action;
  const buy = e.target.dataset.buy;
  const mode = e.target.dataset.mode;
  const sell = e.target.dataset.sell;
  const unlock = e.target.dataset.unlock;

  if (action) {
    const plot = state.plots[action];
    if (!plot.hasStarted) startCycle(action);
    else if (plot.ready) harvest(action);
  }
  if (buy) {
    const plot = state.plots[buy];
    const modeVal = plot.buyMode || 1;
    let count = 1;
    if (modeVal === "max") {
      let temp = plot.plantCost;
      let total = 0;
      while (total + temp <= state.coins && count < 1000) {
        total += temp;
        temp = Math.max(temp + 1, Math.ceil(temp * 1.15));
        count++;
      }
      count = Math.max(1, count - 1);
    } else {
      count = Number(modeVal);
    }
    buyPlant(buy, count);
  }
  if (mode) {
    const plot = state.plots[mode];
    const modes = [1, 10, 100, "max"];
    const idx = modes.indexOf(plot.buyMode || 1);
    plot.buyMode = modes[(idx + 1) % modes.length];
  }
  if (sell) {
    const plot = state.plots[sell];
    const veggie = VEGGIES.find(v => v.id === sell);
    if (!plot.autoSell && plot.inventory > 0) {
      state.coins += plot.inventory * veggie.sellPrice;
      plot.inventory = 0;
    }
  }
  if (unlock) {
    const veggie = VEGGIES.find(v => v.id === unlock);
    if (state.coins >= veggie.firstCost) {
      state.coins -= veggie.firstCost;
      veggie.unlocked = true;
      state.plots[unlock].plants = 1;
      if (veggie.id === "broccoli") {
        const overlay = document.createElement("div");
        overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,0.65);display:flex;align-items:center;justify-content:center;z-index:9999;pointer-events:none;";
        overlay.innerHTML = `
          <div style="text-align:center;color:white;animation:bounce 0.5s infinite;">
            <div style="font-size:5rem;">🥦</div>
            <div style="background:#fbbf24;color:#111;padding:0.6rem 1.2rem;border-radius:10px;margin-top:1rem;font-weight:bold;font-size:1.4rem;">Yendy's Special Reward!!</div>
            <div style="margin-top:1rem;font-size:2rem;">🎆✨🎉</div>
          </div>`;
        document.body.appendChild(overlay);
        setTimeout(() => overlay.remove(), 5000);
      }
    }
  }
  updateUI();
}

function prestige() {
  const broccoliUnlocked = VEGGIES.find(v => v.id === "broccoli")?.unlocked;
  if (!broccoliUnlocked || state.supportive < 1) return;
  const trophiesEarned = state.prestigeUpgrades.perpetualWinner
    ? Math.max(1, Math.floor(state.supportive))
    : 1;
  state.trophies += trophiesEarned;
  state.coins = 0;
  state.supportive = 0;
  VEGGIES.forEach(v => {
    if (v.id !== "kale") v.unlocked = false;
    const p = state.plots[v.id];
    p.plants = v.id === "kale" ? 1 : 0;
    p.plantCost = v.firstCost;
    p.inventory = 0;
    p.progress = 0;
    p.growing = false;
    p.ready = false;
    p.hasStarted = false;
    if (!state.prestigeUpgrades.ongoingSupport) {
      p.autoHarvest = false;
      p.autoSell = false;
      state.upgrades[v.id].harvest = false;
      state.upgrades[v.id].sell = false;
    }
  });
  lastUpgradeState = "";
  updateUI();
}

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.style.display = "none");
    tab.classList.add("active");
    document.getElementById(tab.dataset.tab + "-tab").style.display = "block";
  });
});

document.querySelectorAll(".subtab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".subtab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".subpanel").forEach(p => p.style.display = "none");
    tab.classList.add("active");
    document.getElementById(tab.dataset.subtab + "-panel").style.display = "block";
  });
});

plotsEl.addEventListener("click", onPlotClick);
prestigeBtn.addEventListener("click", prestige);

document.addEventListener("click", (e) => {
  const card = e.target.closest("[data-upgrade]");
  if (!card || card.id === "prestige-btn") return;
  const up = card.dataset.upgrade;
  if (!up || up === "1" || up === "0") return;

  if (up.startsWith("harvest-")) {
    const id = up.split("-")[1];
    const v = VEGGIES.find(x => x.id === id);
    const cost = v.id === "kale" ? 100 : Math.floor(v.firstCost * 10);
    if (state.coins >= cost && !state.upgrades[id].harvest) {
      state.coins -= cost;
      state.upgrades[id].harvest = true;
      state.plots[id].autoHarvest = true;
      lastUpgradeState = "";
      updateUI();
    }
  }
  if (up.startsWith("sell-")) {
    const id = up.split("-")[1];
    const v = VEGGIES.find(x => x.id === id);
    const cost = v.id === "kale" ? 500 : Math.floor(v.firstCost * 50);
    if (state.coins >= cost && !state.upgrades[id].sell) {
      state.coins -= cost;
      state.upgrades[id].sell = true;
      state.plots[id].autoSell = true;
      lastUpgradeState = "";
      updateUI();
    }
  }
  if (up.startsWith("speed-")) {
    const id = up.split("-")[1];
    const v = VEGGIES.find(x => x.id === id);
    const cost = Math.floor(v.firstCost * 100 * Math.pow(1.25, state.upgrades[id].speedBought));
    if (state.coins >= cost) {
      state.coins -= cost;
      state.upgrades[id].speedBought++;
      state.plots[id].speedLevels++;
      lastUpgradeState = "";
      updateUI();
    }
  }
  if (up === "global-speed") {
    const teaCost = Math.floor(1000 * Math.pow(1.25, state.globalSpeedLevels));
    if (state.coins >= teaCost) {
      state.coins -= teaCost;
      state.globalSpeed *= 1.25;
      state.globalSpeedLevels++;
      VEGGIES.forEach(v => {
        if (v.unlocked && !state.globalSpeedAffected.includes(v.id)) {
          state.globalSpeedAffected.push(v.id);
        }
      });
      lastUpgradeState = "";
      updateUI();
    }
  }
  if (up === "autobuy" && state.coins >= 1e12 && !state.autobuy) {
    state.coins -= 1e12;
    state.autobuy = true;
    lastUpgradeState = "";
    updateUI();
  }
  if (up === "farmers-market" && !state.marketUpgrades.farmersMarket && state.coins >= 1000) {
    const beets = VEGGIES.find(v => v.id === "beets");
    if (beets?.unlocked) {
      state.coins -= 1000;
      state.marketUpgrades.farmersMarket = true;
      updateUI();
    }
  }
});

let last = performance.now();
function loop(now) {
  const dt = ((now - last) / 1000) * (state.timeScale || 1);
  last = now;

  VEGGIES.forEach(v => {
    const plot = state.plots[v.id];
    if (plot.autoSell && plot.inventory > 0) {
      state.coins += plot.inventory * v.sellPrice;
      plot.inventory = 0;
    }
  });

  VEGGIES.forEach(v => {
    const plot = state.plots[v.id];
    if (!v.unlocked || !plot.growing || plot.ready) return;
    const cycle = getCycleTime(v, plot);
    plot.progress += dt / cycle;
    if (plot.progress >= 1) {
      plot.progress = 1;
      plot.growing = false;
      plot.ready = true;
      if (plot.autoHarvest) harvest(v.id);
    }
  });

  updateUI();
  requestAnimationFrame(loop);
}

document.getElementById("test-celebration")?.addEventListener("click", () => {
  const overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,0.65);display:flex;align-items:center;justify-content:center;z-index:9999;pointer-events:none;";
  overlay.innerHTML = `
    <div style="text-align:center;color:white;animation:bounce 0.5s infinite;">
      <div style="font-size:5rem;">🥦</div>
      <div style="background:#fbbf24;color:#111;padding:0.6rem 1.2rem;border-radius:10px;margin-top:1rem;font-weight:bold;font-size:1.4rem;">Yendy's Special Reward!!</div>
      <div style="margin-top:1rem;font-size:2rem;">🎆✨🎉</div>
    </div>`;
  document.body.appendChild(overlay);
  setTimeout(() => overlay.remove(), 5000);
});

document.getElementById("time-scale")?.addEventListener("click", (e) => {
  const scale = e.target.dataset.scale;
  if (!scale) return;
  state.timeScale = Number(scale);
  document.querySelectorAll("#time-scale button[data-scale]").forEach(b => {
    b.style.background = b.dataset.scale == scale ? "#3b82f6" : "#475569";
    b.style.color = "white";
  });
});

updateUI();
requestAnimationFrame(loop);
